#include <iostream>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
using namespace std;

void handleFileError(const char* filename) {

/*
	switch ( errno ) {
		case EACCES:
		cerr << "open() file " << filename << " not allowed." << endl;
		break;
		case EDQUOT: 
		cerr << "file " << filename << " too big, user's quota exhausted" << endl;
		break;
		case EEXIST: 
		cerr << "file " << filename << " already exists." << endl;
		break;
		case EFAULT:
		cerr << "file " << filename << " not accessible address space." << endl;
		break;
		case EDQUOT: 
		cerr << "file " << filename << " too big." << endl;
		break;
		case EEXIST: 
		cerr << "file " << filename << " already exists." << endl;
		break;

	}
*/
}

int main(int argc, char** argv)
{
	if (argc < 3) {
        	cerr << "Not enough arguments given" << endl;
		return (-1);
	}
	int iSourceHandle = open(argv[1], O_RDONLY);
	if (iSourceHandle == -1) {
		handleFileError(argv[1]);
		return (-1);
	}

	int iMode = S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH;
	int iDestHandle = open(argv[2], O_CREAT|O_EXCL|O_TRUNC|O_WRONLY, iMode);
	if (iDestHandle == -1) {
		if (errno == EEXIST ) {
			handleFileError(argv[2]);
			cerr << "File " << argv[2] << " already exists." << endl;
		}
		return (-1);
	}
	const int buf_size = 10;
	const char buffer[buf_size] = {};
	int bytes_read = 0;
	int bytes_written = 0;
	cout << argv[1] << " wird nach " << argv[2] << " kopiert.   ";
	bytes_read = read (iSourceHandle, (void*) buffer, buf_size);
//	cerr << "bytes_read: " << bytes_read << endl;
	if (bytes_read == -1) {
		cerr << "read operation failed: errno = " << errno << endl;
	}

	while (bytes_read > 0) {
	
//		cerr << "bytes_read: " << bytes_read << endl;
		bytes_written = write (iDestHandle, (void*)buffer, bytes_read);	
//		cerr << "bytes_written: " << bytes_written << endl;
		if (bytes_written == -1) {
			cerr << "write operation failed: errno = " << errno << endl;
			return (-1);
		}
		bytes_read = read (iSourceHandle, (void*)buffer, buf_size);
		if (bytes_read == -1) {
			cerr << "read operation failed: errno = " << errno << endl;
			return (-1);
		}
	}
	//fsync(iDestHandle);
	close(iDestHandle);
	close(iSourceHandle);
	cout << "DONE" << endl;
	return 0;
}
